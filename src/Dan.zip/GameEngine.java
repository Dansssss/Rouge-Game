import java.util.Scanner;

public class GameEngine {

    Scanner scanner = new Scanner(System.in);

    private final static int P_INITIAL_POSITION_X = 1;
    private final static int P_INITIAL_POSITION_Y = 1;
    private final static int M_INITIAL_POSITION_X = 4;
    private final static int M_INITIAL_POSITION_Y = 2;

    public static void main(String[] args) {

        // TODO: Some starter code has been provided below.
        // Edit this method as you find appropriate.

        Player player=new Player();
        Monster monster=new Monster();
        World world=new World();
        Scanner scanner = new Scanner(System.in);

        // Creates an instance of the game engine.
        GameEngine gameEngine = new GameEngine();

        // Runs the main game loop.
        gameEngine.runGameLoop(player, monster, world, scanner);

    }


    /*
     *  Logic for running the main game loop.
     */
    private void runGameLoop(Player player, Monster monster, World world, Scanner scanner) {

        displayTitleText(player, monster);
        String inputCommand = "";

        while(true) {
            doInputCommand(inputCommand, player, monster, world, scanner);
        }
    }

    /*
     *  Displays the title text.
     */
    private void displayTitleText(Player player, Monster monster) {

        String titleText = " ____                        \n" +
                "|  _ \\ ___   __ _ _   _  ___ \n" +
                "| |_) / _ \\ / _` | | | |/ _ \\\n" +
                "|  _ < (_) | (_| | |_| |  __/\n" +
                "|_| \\_\\___/ \\__, |\\__,_|\\___|\n" +
                "COMP90041   |___/ Assignment ";

        System.out.println(titleText);

        System.out.println();

        displayPlayer(player);
        displayMonster(monster);

        System.out.println();
        System.out.println();

        displayContent();

    }

    /*
     *  Displays the player's information below title
     */
    private void displayPlayer(Player player) {

        //if there is no player, print Player: [None]  |
        if (player.getName().equals("0-inCaseSomeoneNameLikeThis")) {
            System.out.print("Player: [None]  |");
        }

        //if there is one, print player information
        else System.out.printf("Player: %s %d/%d  |", player.getName(), player.getHealth(), player.getMaxHealth());
    }

    /*
     *  Displays the monster's information below title
     */
    private void displayMonster(Monster monster) {

        //Monster: [None]
        if (monster.getName().equals("0-inCaseSomeoneNameLikeThis")) {
            System.out.print(" Monster: [None]");
        }
        //if there is one, print monster information
        else {
            System.out.printf(" Monster: %s %d/%d", monster.getName(), monster.getHealth(), monster.getMaxHealth());
            System.out.println();
        }
    }

    /*
     *  Displays hint content below player and monster
     */
    private void displayContent() {

        System.out.println("Please enter a command to continue.");
        System.out.println("Type 'help' to learn how to get started.");

    }

    /*
     *  Do every input command
     */
    private void doInputCommand(String inputCommand, Player player, Monster monster, World world, Scanner scanner) {
        System.out.print("\n> ");
        inputCommand = scanner.nextLine();
        switch (inputCommand) {
            case "help":
                displayHelpContent();
                break;
            case "commands":
                displayCommandsContent();
                break;
            case "player":
                if (player.getName().equals("0-inCaseSomeoneNameLikeThis")) {
                    playerCreation(player, monster);
                } else {
                    System.out.println(player.getName() + " (Lv. 1)");
                    System.out.println("Damage: " + player.getDamage());
                    System.out.println("Health: " + player.getMaxHealth() + "/" + player.getMaxHealth());
                    returnMainMenu(player, monster);

                }

                break;
            case "monster":
                monsterCreation(player, monster);
                break;
            case "start":
                start(player, monster, world);
                break;
            case "exit":
                exit();
                break;
        }
    }

    /*
     *  Displays help information
     */
    private void displayHelpContent() {

        String helpContent = """
                Type 'commands' to list all available commands
                Type 'start' to start a new game
                Create a character, battle monsters, and find treasure!""";

        System.out.print(helpContent);
        System.out.println();
    }

    /*
     *  Displays commands
     */
    private void displayCommandsContent() {

        String CommandsContent = """
                help
                player
                monster
                start
                exit""";
        System.out.print(CommandsContent);
        System.out.println();

    }

    /*
     *  Check if the first character of input is a letter
     */
    private boolean checkLetter(String args) {
        char x = args.charAt(0);
        return (x >= 'a' && x <= 'z') || (x >= 'A' && x <= 'Z');
    }

    /*
     *  Check if there is an input
     */
    private boolean checkInputLength(String input) {
        return input.length() != 0;
    }

    /*
     *  Check if input is all integer
     */
    private boolean checkInputInt(String inputInt) {
        if (inputInt.length() == 0) return false;
        for (int i = 0; i < inputInt.length(); i++) {
            if (!Character.isDigit(inputInt.charAt(i))) return false;
        }
        return true;
    }

    /*
     *  Return to the main menu
     */
    public void returnMainMenu(Player player, Monster monster) {
        System.out.println();
        System.out.println("(Press enter key to return to main menu)");

        String enterKey = scanner.nextLine();
        if(enterKey.equals("")){

            displayTitleText(player,monster);

        }
    }

    /*
     *  Create a player if there is none
     */
    private Player playerCreation(Player player, Monster monster) {
        if (player.getName().equals("0-inCaseSomeoneNameLikeThis")) {
            System.out.println("What is your character's name?");

            String name = scanner.nextLine().strip();
            player.setName(name);
            // if the player name input is valid
            if (checkInputLength(name) && checkLetter(name)) {
                //System.out.print(player.getName());
                System.out.println("Player '" + name + "' created.");
                returnMainMenu(player,monster);
            }

            // if invalid
            else if (!checkLetter(name)) {
                System.out.println("The first character should be a letter.");
            } else if (!checkInputLength(name)) {
                System.out.println("Please enter a player name.");
            }
        } else System.out.println(player);

        return player;

    }

    /*
     *  Create a monster if there is none
     */
    private Monster monsterCreation(Player player, Monster monster) {

        System.out.print("Monster name: ");
        String name = scanner.nextLine().strip();

        checkInputLength(name);

        System.out.print("Monster health: ");
        String healthString = scanner.nextLine().strip();

        checkInputInt(healthString);
        int health = Integer.parseInt(healthString);

        System.out.print("Monster damage: ");
        String damageString = scanner.nextLine().strip();

        checkInputInt(damageString);
        int damage = Integer.parseInt(damageString);
        if ( health >= 0 && damage >= 0 ) {

            //all the information is valid, store it
            monster.setName(name);
            monster.setMaxHealth(health);
            monster.setHealth(health);
            monster.setDamage(damage);

            System.out.println("Monster '" + name + "' created.");
            returnMainMenu(player,monster);
        }

        return monster;
    }

    /*
     *  Terminate the application instead of using System.exit(0)
     */
    private void exit() {
        System.out.println("Thank you for playing Rogue!");
        Runtime runtime = Runtime.getRuntime();
        runtime.exit(0);

    }

    /*
     *  Start the game world
     */
    private void start(Player player, Monster monster, World world) {
        if (player.getName().equals("0-inCaseSomeoneNameLikeThis")) {
            System.out.println("No player found, please create a player with 'player' first.");
            returnMainMenu(player,monster);
        }

        else if (monster.getName().equals("0-inCaseSomeoneNameLikeThis")) {
            System.out.println("No monster found, please create a monster with 'monster' first.");
            returnMainMenu(player,monster);
        }
        else if ((player.getHealth()!=player.getMaxHealth() || monster.getHealth()!=monster.getMaxHealth())){

            //World world = new World();
            player.setMaxHealth(player.getMaxHealth());
            monster.setMaxHealth(monster.getMaxHealth());

            player.setX(P_INITIAL_POSITION_X);
            player.setY(P_INITIAL_POSITION_Y);

            monster.setX(M_INITIAL_POSITION_X);
            monster.setY(M_INITIAL_POSITION_Y);

            startGame(player,monster,world,scanner);
        }
        else{
            startGame(player,monster,world,scanner);
        }
    }

    /*
     *  Start the game, mainly focus on battle round
     */
    public void startGame(Player player, Monster monster, World world, Scanner scanner){
        World.map(player,monster);
        boolean exitLater = false;

        while(!world.ifTheyMeet(player,monster) && !exitLater){
            System.out.print("> ");
            String move = scanner.next();
            checkHome(move,player,monster);
            exitLater = move.equals("exit");

            world.movement(move,player,monster);

            }

        if(world.ifTheyMeet(player,monster))    //player encounters monster
            world.battleRound(player,monster);

        System.out.println();
        System.out.println("(Press enter key to return to main menu)");
        String enterKey = scanner.nextLine();
        if(enterKey.equals("")) displayTitleText(player,monster);
        }

    /*
     *  Return to the main menu if user inputs home command
     */
    public void checkHome(String inputCommand, Player player, Monster monster){
        if(inputCommand.equals("home")){
            System.out.println("Returning home...");

            returnMainMenu(player, monster);

        }
    }
}