public class Player {

    private String name;    //Player's name
    private int maxHealth;  //The maximum of health
    private final int damage; //Damage the player deals
    private int health; //Health the player holds

    private int x;
    private int y;

    private final static int level = 1;
    private final static int TIMES = 3;
    private final static int INITIAL_HEALTH = 17;
    private final static int INITIAL_POSITION_X = 1;
    private final static int INITIAL_POSITION_Y = 1;

    Player(){this("0-inCaseSomeoneNameLikeThis");}

    Player(String name){
        setName(name);
        this.maxHealth = INITIAL_HEALTH + level * TIMES;    // max health = 17 + level * 3
        health = maxHealth;
        this.damage = 1 + level; // damage = 1 + level

        this.x = INITIAL_POSITION_X;
        this.y = INITIAL_POSITION_Y;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String newName) {
        this.name = newName;
    }

    public int getMaxHealth() {
        return maxHealth;
    }

    public void setMaxHealth(int maxHealth) {
        this.maxHealth = maxHealth;
    }

    public int getDamage() {
        return damage;
    }

    public void setHealth(int health) {
        this.health = health;
    }
    public int getHealth() {
        return health;
    }

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    /*
     * Calculate monster's health after the attack by player
     */
    public void playerAttackMonster(Monster monster) {
        int healthBeforeAttack = monster.getHealth();
        int healthAfterAttack = healthBeforeAttack - this.damage;

        monster.setHealth(healthAfterAttack);
    }

}
