public class World {

    private final static int DEPTH = 4;
    private final static int WIDTH = 6;
    private final int depth;
    private final int width;

    World(){
        this.depth = DEPTH;
        this.width = WIDTH;
    }

    /*
     *  Print the map
     */
    public static void map(Player player, Monster monster) {
        for(int depth = 0; depth < DEPTH; depth++) {
            for (int width = 0; width < WIDTH; width++) {
                if (width == player.getX() && depth == player.getY()) {
                    System.out.print(player.getName().toUpperCase().charAt(0) + "");
                }
                else if(width == monster.getX() && depth == monster.getY()) {
                    System.out.print(monster.getName().toLowerCase().charAt(0) + "");
                }
                else
                    System.out.print(".");
            }
            System.out.println();
        }
    }

    /*
     *  Use "wsad" command to move the player
     */
    public void movement(String move, Player player, Monster monster) {

        int newPositionX;
        int newPositionY;

        if(move.length() == 1 && "wsad".contains(move)) {

            if (move.equalsIgnoreCase("w")) {
                newPositionY = player.getY() - 1;
                player.setY(newPositionY);
                if (ifInside(player)) {
                    if (!ifTheyMeet(player, monster)) {
                        map(player, monster);
                    }
                } else {
                    /*
                     *  if the movement is invalid (i.e. outside the map & meet the monster)
                     *  the position should restore
                     *  same below
                     */
                    newPositionY = player.getY() + 1;
                    player.setY(newPositionY);
                    map(player, monster);
                }

            }

            if (move.equalsIgnoreCase("s")) {
                newPositionY = player.getY() + 1;
                player.setY(newPositionY);
                if (ifInside(player)) {
                    if (!ifTheyMeet(player, monster)) {
                        map(player, monster);
                    }
                } else {
                    newPositionY = player.getY() - 1;
                    player.setY(newPositionY);
                    map(player, monster);
                }
            }

            if (move.equalsIgnoreCase("a")) {
                newPositionX = player.getX() - 1;
                player.setX(newPositionX);
                if (ifInside(player)) {
                    if (!ifTheyMeet(player, monster)) {
                        map(player, monster);
                    }
                } else {
                    newPositionX = player.getX() + 1;
                    player.setX(newPositionX);
                    map(player, monster);
                }
            }

            if (move.equalsIgnoreCase("d")) {
                newPositionX = player.getX() + 1;
                player.setX(newPositionX);
                if (ifInside(player)) {
                    if (!ifTheyMeet(player, monster)) {
                        map(player, monster);
                    }
                } else {
                    newPositionX = player.getX() - 1;
                    player.setX(newPositionX);
                    map(player, monster);
                }
            }
        }
    }

    /*
     *  Check if player goes out of the map
     */
    public boolean ifInside(Player player){

        //check whether the player is inside the map
        int x = player.getX();
        int y = player.getY();

        if(x >= 0 && x < WIDTH) {
            return y >= 0 && y < DEPTH;
        }else return false;
    }

    /*
     *  Check if player meets monster
     */
    public boolean ifTheyMeet(Player player, Monster monster){
        return player.getX()==monster.getX() &&
                player.getY()==monster.getY();
    }

    /*
     *  Show the battle information
     */
    public void battleRound(Player player, Monster monster){
        System.out.printf("%s encountered a %s!\n", player.getName(), monster.getName());

        // if player/monster dies the loop stops
        while (player.getMaxHealth() > 0 && monster.getHealth() > 0){
            System.out.println();
            System.out.printf("%s |", player.getName() + " " + player.getHealth() + "/" + player.getMaxHealth());
            System.out.printf(" %s", monster.getName() + " " + monster.getHealth() + "/" + monster.getMaxHealth());

            player.playerAttackMonster(monster);

            System.out.println();
            System.out.printf("%s attacks %s for %d damage.\n", player.getName(), monster.getName(), player.getDamage());

            if(monster.getHealth()>0){
                monster.monsterAttackPlayer(player);
                System.out.printf("%s attacks %s for %d damage.\n", monster.getName(), player.getName(), monster.getDamage());
            }
            System.out.println();
        }
        if(player.getMaxHealth()>0){
            System.out.println(player.getName()+" wins!");
        }
        else if(monster.getHealth()>0){
            System.out.println(monster.getName()+" wins!");
        }
    }
}



