public class Monster {
    private String name;    //Monster's name
    private int maxHealth;  //The maximum of health
    private int health; //Health the monster holds
    private int damage; //Damage the monster deals

    private int x;
    private int y;

    Monster() {
        this("0-inCaseSomeoneNameLikeThis", 0, 0);
    }

    private final static int INITIAL_POSITION_X = 4;
    private final static int INITIAL_POSITION_Y = 2;

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public Monster(String name, int maxHealth, int damage) {
        setName(name);
        setMaxHealth(maxHealth);
        setHealth(health);
        setDamage(damage);

        this.x = INITIAL_POSITION_X;
        this.y = INITIAL_POSITION_Y;
    }

    /*
     * Calculate player's health after the attack by monster
     */
    public void monsterAttackPlayer(Player player) {
        int healthBeforeAttack = player.getMaxHealth();
        int healthAfterAttack = healthBeforeAttack - this.damage;

        player.setHealth(healthAfterAttack);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getMaxHealth() {
        return maxHealth;
    }

    public void setMaxHealth(int maxHealth) {
        this.maxHealth = maxHealth;
    }

    public int getHealth() {
        return health;
    }

    public void setHealth(int health) {
        this.health = health;
    }

    public int getDamage() {
        return damage;
    }

    public void setDamage(int damage) {
        this.damage = damage;
    }
}